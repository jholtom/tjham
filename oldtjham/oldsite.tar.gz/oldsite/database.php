<?
include("access.php");
mysql_connect ("mysql.tjhsst.edu", "abalding", "$andrew")
	or die ('I cannot connect to the database.  Make sure that mysql is
installed and that you are trying to log in as a valid user.');

mysql_select_db ('abalding')
	or die ('The database specified in database_name must exist and must be
accessible by the user specified in mysql_connect');

# make a query on a table in your database
$query = "SELECT * FROM hamcontacts";
$query_result_handle = mysql_query ($query)
	or die ('The query failed!  table_name must be a valid table name that
exists in the database specified in mysql_select_db');

# make sure that we recieved some data from our query
$num_of_rows = mysql_num_rows ($query_result_handle)
	or die ("The query: '$query' did not return any data");

?>

<table border="1" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="25%" align="center"><b>City</b></td>
<td width="25%" align="center"><b>Country</b></td>
<td width="25%" align="center"><b>Call Sign</b></td>
<td width="25%" align="center"><b>Date</b></td>
</tr>

<?

# use mysql_fetch_row to retrieve the results
for ($count = 1; $row = mysql_fetch_row ($query_result_handle); ++$count)
  {
  	?> <tr>
	<td width="25%" align="center"><? print "$row[0]"; ?></td>
	<td width="25%" align="center"><? print "$row[1]"; ?></td>
	<td width="25%" align="center"><? print "$row[2]"; ?></td>
	<td width="25%" align="center"><? print "$row[3]"; ?></td>
	</tr>  
<?
  }



?>
</table>
