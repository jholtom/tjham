<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php
/*
Copyright Lee Burton 2004
You may use this style sheet as long as you give me some credit.
If you modify it... please send me it.
lee at sg1net.com
*/
require_once('inc.inc');
require_once('count.inc');
?>
<html>
<head>
<title>TJ Amateur Radio Club</title><?php
?>
<meta http-equiv="content-script-type" content="text/javascript">
<meta http-equiv="content-style-type" content="text/css">
<meta content="TJHAM" name="description">
<meta content="" name="keywords">
<meta content="Lee Burton" name="author">
<link rel="stylesheet" type="text/css" href="css/default.css">
<link rel="icon" href="images/icon.png" type="image/png">
<script language="JavaScript" type="text/javascript">
var allCookies = document.cookie.split("; "); //in case you have more than one cookie on your site
var websnSkin = ""
for (i=0; i < allCookies.length; i++) {
   crumb = allCookies[i].split("="); 
   if (crumb[0] == "skin") { // find the cookie called skin
     websnSkin = crumb[1]; // assign it's value to a variable
   }
   if (websnSkin == "") {
     websnSkin = "default"
   }
}
document.write ("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/" + websnSkin + ".css\" id=\"skin\" />")
</script>
<script language="JavaScript" src="skin.js"  type="text/javascript"></script>
</head>
<body>
<div class="box" align="center">

<?php
top();
include 'box.inc';
bottom();
?>
</div><br>
<div class="menu"><img src="images/logo.jpg" height="158" width="136" border="0" alt="TJHAM">
</div>
 <div class="contentWrapper">
<?php 
top();
include 'menu.inc';
bottom();
?>
</div>
<div class="main">
<?php
top();
$thisis="0";
                $handle=fopen(menuok, "r");
                        while (!feof ($handle)) {
                                $com = fgets($handle);
                                $com2=trim($com);
                                if ($com2==$page) {
                                        $thisis="1";
                                }
                        }
if ($thisis=="1" || $page == "") {
if ($page != "") {
$pa = "$page.inc";
include $pa;
} else {
$page="home";
include 'home.inc';
}
} else {
include 'error.inc';
}
bottom();
?>
<br><center>&copy; Lee Burton 2004 and the TJHSST HAM Club<br><a href="http://www.vim.org/"><img border="0" src="vim.png" alt="Created With Vim"></a>
<a href="http://validator.w3.org/check?uri=referer"><img border="0" src="http://www.w3.org/Icons/valid-html401" alt="Valid HTML 4.01!" height="31" width="88"></a> <a href="http://jigsaw.w3.org/css-validator/check/referer">
  <img style="border:0;width:88px;height:31px"
         src="http://jigsaw.w3.org/css-validator/images/vcss" 
	        alt="Valid CSS!">
		 </a></center>
<center><a href="http://www.mozilla.org/products/firefox/" title="Get Firefox - Take Back the Web"><img src="http://www.mozilla.org/products/firefox/buttons/getfirefox_large.png" width="178" height="60" border="0" alt="Get Firefox"></a></center>
<center>So far <?php $foo=explode("\n",file_get_contents("ip/countip")); echo count($foo)-1;?> different ip addresses have paid a visit (Since Jun 8,2004).</center></div>
</body>
</html>
