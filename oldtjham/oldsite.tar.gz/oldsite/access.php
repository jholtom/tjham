<?
$andrew = "temp123";

?>
