<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" color="#FFFFFF" face="verdana, helvetica, arial, sans-serif">About
        Us</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
        <p align="center"><font face="verdana, helvetica, arial, sans-serif"><br><font size="2">What
        is the Amateur Radio Club and what do we do?</font></font></p>
        <p align="center"><font face="verdana, helvetica, arial, sans-serif" size="2">As
        amateur radio operators, we can talk to fellow &quot;hams&quot; around
        the world using HF frequencies similar to those that AM radio
        uses.&nbsp;&nbsp;We also learn about radio propagation, antennas, solar
        cycles, and electronics. Another key part of amateur radio is service.
        Hams often assist in events, such as the Marine Corp Marathon, providing
        communications for the events. Amateur operators also provide backup
        communications when other forms of communication, such as phones and
        cell phones, are disabled.</font></p>
        <p align="center"><font face="verdana, helvetica, arial, sans-serif" size="2">Our
        club meets Wednesday B blocks. Our sponsor, Mr. Bosch, is a ten-year
        veteran of ham radio.</font></p>
        <p align="center"><font face="verdana, helvetica, arial, sans-serif" size="2"><a href="constitution.doc"><font color="#000000">Click
        here for our constitution</font></a></font></p>
      </td>
    </tr>
  </table>
  </center>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
