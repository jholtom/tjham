<?
mysql_connect ("localhost", "abaldinger", "caps592")
	or die ('I cannot connect to the database.  Make sure that mysql is
installed and that you are trying to log in as a valid user.');

mysql_select_db ('abaldinger')
	or die ('The database specified in database_name must exist and must be
accessible by the user specified in mysql_connect');

# make a query on a table in your database
$query = "SELECT * FROM contacts";
$query_result_handle = mysql_query ($query)
	or die ('The query failed!  table_name must be a valid table name that
exists in the database specified in mysql_select_db');

# make sure that we recieved some data from our query
$num_of_rows = mysql_num_rows ($query_result_handle)
	or die ("The query: '$query' did not return any data");

?>

<table border="0" cellpadding="0" cellspacing="0" width="75%">
<tr>
<td><b><u> City </td>
<td><b><u> Country </td>
<td><b><u> Call Sign </td>
<td><b><u> Date </b></u></td>
</tr>

<?

# use mysql_fetch_row to retrieve the results
for ($count = 1; $row = mysql_fetch_row ($query_result_handle); ++$count)
  {
  	?> <tr>
	<td> <? print "$row[0]"; ?> </td>
	<td> <? print "$row[1]"; ?> </td>
	<td> <? print "$row[2]"; ?> </td>
	<td> <? print "$row[3]"; ?> </td>
	<p> </tr> <p> 
<?
  }



?>
</table>
