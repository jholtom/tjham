<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" face="Verdana" color="#FFFFFF">Online
        Log</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
        <p align="center">&nbsp;</p>
        <p align="center"><img border="0" src="world18.gif" width="431" height="218"></p>
        <p align="center"><font size="2" face="Verdana">Who Have We Contacted? Find Out Here!</font></p>
        <p align="center"><font size="2" face="Verdana">
        <? include ("database.php"); ?></font></p>
<p>
<form method="POST" action="addcontact.php">
  
  <div align="center">
    <table border="0" cellpadding="0" cellspacing="0" width="70%">
      <tr>
        <td width="50%">
          <p align="right">City</td>
        <td width="50%">&nbsp;<input type="text" name="city" size="20"></td>
        </tr>
      <tr>
        <td width="50%">
          <p align="right">Country</td>
        <td width="50%">&nbsp;<input type="text" name="country" size="20"></td>
        </tr>
      <tr>
        <td width="50%">
          <p align="right">Callsign</td>
        <td width="50%">&nbsp;<input type="text" name="callsign" size="20"></td>
        </tr>
      <tr>
        <td width="50%">
          <p align="right">Date</td>
        <td width="50%">&nbsp;<input type="text" name="date" size="20" value="mm/dd/yy"></td>
        </tr>
      <tr>
        <td width="50%">
          <p align="right">Password</td>
        <td width="50%">&nbsp;<input type="password" name="pass" size="20"></td>
      </tr>
      <tr>
        <td width="50%">
          <p align="right"></td>
        <td width="50%">&nbsp;<input type="submit" value="Submit" name="B1"><input type="reset" value="Reset" name="B2"></td>
        </tr>
      </table>
  </div>
  <p>&nbsp;</p>
</form>

        <p align="center">&nbsp;</p>
      </td>
    </tr>
  </table>
  </center>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
