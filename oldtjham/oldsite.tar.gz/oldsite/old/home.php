<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" face="verdana, helvetica, arial, sans-serif" color="#FFFFFF">Welcome
        to TJ Amateur Radio!</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
        <p align="center"><font face="verdana, helvetica, arial, sans-serif"><br></font><img border="0" src="The_Room.jpg" width="288" height="216"></p>
        <p align="center">
        <a href="index.php?page=signup"><font size="2" face="verdana, helvetica, arial, sans-serif">
        <br>
<font color="#000000">
Click to subscribe to TJHam, our mailing list</font></font></a></p>
      </td>
    </tr>
  </table>
  </center>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
