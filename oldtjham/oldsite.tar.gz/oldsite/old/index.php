<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>TJHSST Amateur Radio Club</title>
<style type="text/css">
	<!--
		BODY	   { FONT-FAMILY: "Arial, Geneva"; FONT-SIZE: 10pt; }
		A:link    { COLOR: white; TEXT-DECORATION: none }
		A:visited { COLOR: white; TEXT-DECORATION: none}
		A:active  { COLOR: white; TEXT-DECORATION:  none}
		A:hover   { COLOR: #ffc600; TEXT-DECORATION: none }

		A:link.nav    { COLOR: #738cbd; TEXT-DECORATION: none }
		A:visited.nav { COLOR: #738cbd; TEXT-DECORATION: none }
		A:active.nav  { COLOR: #738cbd; TEXT-DECORATION: none }
		A:hover.nav   { COLOR: #738cbd; TEXT-DECORATION: none }
	-->
	</style>
</head>

<body text="#000000" bgcolor="#FFFFFF">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="760" bordercolor="#000000">
    <tr>
      <td><img border="0" src="newestbanner.gif" width="760" height="100"></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="2" cellpadding="0" cellspacing="0" width="760" bordercolor="#000000">
    <tr>
      <td width="158" background="back.gif" valign="top">
        <p align="center">&nbsp;
        <div align="center">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%" height="10"><font size="2"><b>&nbsp;<a href="index.php">Home</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%"><font size="2"><b>&nbsp;<a href="index.php?page=aboutus">About
                Us</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%"><font size="2"><b>&nbsp;<a href="index.php?page=news">News</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%"><font size="2"><b>&nbsp;<a href="index.php?page=contacts">Online
                Log</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%"><font size="2"><b>&nbsp;<a href="index.php?page=resources">Resources</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"><img border="0" src="bullet.gif" width="10" height="10"></td>
              <td width="92%"><font size="2"><b>&nbsp;<a href="index.php?page=pictures">Pictures</a></b></font></td>
            </tr>
            <tr>
              <td width="7%"></td>
              <td width="12%"></td>
              <td width="92%"></td>
            </tr>
          </table>
        </div>
      </td>
      <td width="598" valign="top">
         <font size="2" face="Verdana"><br>
         <?
		if (!isset($page)) 
		$page = "home"; 
		if(file_exists("$page.php")) {
		include ("$page.php"); }
		else { 
		include("404.php");
		} ?></font>
      </td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="2" cellpadding="0" cellspacing="0" width="760" bordercolor="#000000">
    <tr>
      <td bgcolor="#FFC600">
        <p align="center"><font size="2" face="Verdana">� 2002 :: Andrew
        Baldinger &amp; Amateur Radio Club</font></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>
