<form method=GET action="http://groups.yahoo.com/subscribe/TJHam">
<div align="center">
  <center>
<table cellspacing=0 cellpadding=2 border=0 bgcolor=#FFFFCC>
  <tr>
    <td colspan=2 align=center>
      <p align="center">
      <b><font face="Verdana" size="3">Subscribe to TJHam</font></b>
      </p>
    </td>
  </tr>
  <tr>
    <td>
      <p align="center">
      <input type=text name="user" value="enter email address" size=20>
      </p>
    </td>
    <td>
      <p align="center">
      <input type=image border=0 alt="Click here to join TJHam"
       name="Click here to join TJHam"        src="join.gif" width="91" height="52">
      </p>
    </td>
  </tr>
  <tr align="center">
    <td colspan="2">
      <p align="center"><font size="2" face="Verdana" color="#000000">
      Powered by </font> <a href="http://groups.yahoo.com/"><font size="2" face="Verdana" color="#000000">groups.yahoo.com</font></a>
      </p>
    </td>
  </tr>
</table>
  </center>
</div>
</form>
