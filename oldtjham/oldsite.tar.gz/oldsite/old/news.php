<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" color="#FFFFFF" face="verdana, helvetica, arial, sans-serif">Latest
        News</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
       <font size="2" face="Verdana">
      <br> <? include("shownews.php"); ?></font> <br>
        <p align="center"><font size="2" face="Verdana"><a href="addnews.htm"><font color="#000000">Click
        here to add news</font></a></font></p>
      </td>
    </tr>
  </table>
  </center>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
