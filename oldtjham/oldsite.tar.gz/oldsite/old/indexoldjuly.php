<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<!--- Coded by Andrew Baldinger -->

<title>TJ Amateur Radio</title>
<style type="text/css">
	<!--
		BODY	   { FONT-FAMILY: "Arial, Geneva"; FONT-SIZE: 10pt; }
		A:link    { COLOR: white; TEXT-DECORATION: underline }
		A:visited { COLOR: white; TEXT-DECORATION: underline}
		A:active  { COLOR: white; TEXT-DECORATION:  underline}
		A:hover   { COLOR: red; TEXT-DECORATION: none }

		A:link.nav    { COLOR: #738cbd; TEXT-DECORATION: none }
		A:visited.nav { COLOR: #738cbd; TEXT-DECORATION: none }
		A:active.nav  { COLOR: #738cbd; TEXT-DECORATION: none }
		A:hover.nav   { COLOR: #738cbd; TEXT-DECORATION: underline }
	-->
	</style>
</head>

<body>

<div align="center">
  <center>
  <table border="1" cellpadding="0" cellspacing="0" width="750" bordercolor="#000000">
    <tr>
      <td>


<font face="verdana, helvetica, arial, sans-serif">


<img border="0" src="hamhead.gif" align="top" width="750" height="90">

</font>

<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" width="750">
    <tr>
      <td width="146" bgcolor="#003399" valign="top">
      &nbsp;
      <div align="center">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
          <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php">Home</a></font></td>
          </tr>
          <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php?page=aboutus">About Us</a></font></td>
          </tr>
          <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php?page=news">News</a></font></td>
          </tr>
          <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php?page=contacts">Online
              Log</a></font></td>
          </tr>
          <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php?page=resources">Resources</a></font></td>
          </tr>
           <tr>
            <td width="13%" align="right"><font face="verdana, helvetica, arial, sans-serif"><img border="0" src="bullet.gif" width="10" height="10"></font></td>
            <td width="87%"><font size="2" face="verdana, helvetica, arial, sans-serif">&nbsp;<a href="index.php?page=pictures">Pictures</a></font></td>
          </tr>
        </table>
      </div>
      <p><font face="verdana, helvetica, arial, sans-serif"><br>
      </font>
      </p>
 </td>
      <td width="600" valign="top"><font face="verdana, helvetica, arial, sans-serif"><br>
        <font size="2">
       <? 
		if (!isset($page)) $page = "home";
       if(file_exists("$page.php")) {
		include ("$page.php");
		}
		else {
		include("404.php");
		}
		?></font>
        </font>
      </td>
    </tr>
  </table>
</div>


      </td>
    </tr>
    <td bgcolor="#000000">
      <p align="center"><font size="2" face="verdana, helvetica, arial, sans-serif" color="#FFFFFF">Designed
      and Maintained by Andrew Baldinger</font>
  </table>
  </center>
</div>


</body>

</html>
