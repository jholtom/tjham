<?
mysql_connect ("localhost", "abaldinger", "caps592")
	or die ('I cannot connect to the database.  Make sure that mysql is
installed and that you are trying to log in as a valid user.');

mysql_select_db ('abaldinger')
	or die ('The database specified in database_name must exist and must be
accessible by the user specified in mysql_connect');

# make a query on a table in your database
$query = "SELECT * FROM news";
$query_result_handle = mysql_query ($query)
	or die ('The query failed!  table_name must be a valid table name that
exists in the database specified in mysql_select_db');

# make sure that we recieved some data from our query
$num_of_rows = mysql_num_rows ($query_result_handle)
	or die ("The query: '$query' did not return any data");

$today = date("F j, Y");                 
if ($pass == "tjhamiscool"){
mysql_query("INSERT INTO news VALUES ('$today', '$message')");
print "Updated";
}

else{
print "Invalid password";}

?>