<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>TJHSST Amateur Radio Club</title>
<TITLE>TJHSST Amateur Radio Club</TITLE>
             <META NAME="Keywords" CONTENT="">
             <META NAME="Description" CONTENT="The Thomas Jefferson Class of 2004 website">
             <META NAME="Author" CONTENT="Andrew Baldinger">
<STYLE TYPE="text/css"> 
<!-- 
.item {color: white; 
} 
.highlight 
{color: blue;
} 
// --> 
</STYLE>
<SCRIPT LANGUAGE="JavaScript"> 
<!--
function rollon() 
{ if (window.event.srcElement.className == "item")
 { window.event.srcElement.className = "highlight"; 
}
 } 
function rolloff() 
{ if (window.event.srcElement.className == "highlight") 
{ window.event.srcElement.className = "item"; 
}
 } 

document.onmouseover = rollon; 
document.onmouseout = rolloff;
 // --> 
</SCRIPT>
</head>

<body>

<!-- Page top -->

<table border="0" width="750" cellspacing="0" cellpadding="0">
  <tr>
    <td width="750" bgcolor="#000000" colspan="2">

<!-- Page Banner below -->

      <p align="center"><img border="0" src="image1.jpg" width="750" height="90">
    </td>
  </tr>
<tr><td width="143" bgcolor="#000000" height="6"><SPACER TYPE="block" WIDTH=143 HEIGHT=1 ALIGN="bottom"></td><td width=607 bgcolor="black" height="1"><SPACER TYPE="block" WIDTH=607 HEIGHT=1 ALIGN="bottom"></td></tr>

<!-- Poll inserted below -->

  <tr>
    <td width="143" bgcolor="#808080" valign="top" height="100%">
    <div align="justify">
      <table border="0" cellspacing="1" width="100%" >
     
        <br>
        <tr>
          <td width="100%"><A CLASS="item" HREF="index.php?page=home">Home</A></td>
        </tr>
        <tr>
          <td width="100%"><A CLASS="item" HREF="index.php?page=members">Member Info</A></td>
        </tr>
        <tr>
          <td width="100%"><A CLASS="item" HREF="index.php?page=about">About</A></td>
        </tr>
        <tr>
          <td width="100%"><A CLASS="item" HREF="index.php?page=contact">Contact</A></td>
        </tr>
        <tr>
          <td width="100%"><A CLASS="item" HREF="index.php?page=links">Links</A></td>
        </tr>
      </table>
    </div>
    &nbsp;
	</td>

<!-- Content goes below -->

    <td width="607" valign="top" background="images2/bgimage.jpg"><center>
   		<table width="605" valign="top" border="0">
		<tr><td width="605" valign="top">
		<? 
		if (!isset($page)) $page = "home";
		if(file_exists("$page.htm")) {
		include ("$page.htm");
		}
		else {
		include("404.htm");
		}
		?>
		</td>
		</tr>
		</table></center>
      <p align="center"><b>Copyright 2001 -- TJHSST Amateur Radio Club</b></p>
    </td>
  </tr>
</table>

</body>

</html>
