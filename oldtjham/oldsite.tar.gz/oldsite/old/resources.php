<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" face="Verdana" color="#FFFFFF">Resources</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
        <p align="center"><font size="2" face="Verdana"><br>The following is a
        listing of materials for information about Amateur Radio</font></p>
        <div align="center">
          <center>
          <table border="1" cellpadding="0" cellspacing="0" width="70%" bordercolor="#000000">
            <tr>
              <td width="50%" bgcolor="#C0C0C0"><font size="2" face="Verdana"><b>Name</b></font></td>
              <td width="50%" bgcolor="#C0C0C0"><font size="2" face="Verdana"><b>Author
                / Publisher</b></font></td>
            </tr>
            <tr>
              <td width="50%"><font size="2" face="Verdana">Add here</font></td>
              <td width="50%"><font size="2" face="Verdana">Add here</font></td>
            </tr>
          </table>
          </center>
        </div>
        <p align="center"><font size="2" face="Verdana">If you would like to add
        a resource, please email <a href="mailto:abaldinger@cox.net"><font color="#000000">Andrew
        (abaldinger@cox.net)</font></a></font>


      </td>
    </tr>
  </table>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
