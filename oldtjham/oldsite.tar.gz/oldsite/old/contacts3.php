<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Contacts Made</title>
</head>

<body>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%" bgcolor="#003399">
        <p align="center"><b><font size="3" face="Verdana" color="#FFFFFF">Online
        Log</font></b></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="80%">
    <tr>
      <td width="100%">
        <p align="center"><br><img border="0" src="world18.gif" width="431" height="218"></p>
        <p align="center"><font size="2" face="Verdana">Who Have We Contacted
        Today? Find Out Here!</font></p>
        <p align="center"><font size="2" face="Verdana">&lt;database log
        here&gt;</font></p>
        <p align="center">&nbsp;</p>
      </td>
    </tr>
  </table>
  </center>
</div>
<p align="center">&nbsp;</p>

</body>

</html>
